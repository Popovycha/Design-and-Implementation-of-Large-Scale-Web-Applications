"use strict";

/*
   New Perspectives on HTML5 and CSS3, 7th Edition
   Tutorial 10
   Review Assignment

   Author: Artem Popovych
   Date:  06/23/2020 

	
*/

var thisDay = new Date("August 30, 2018");

var tableHTML = "<table id = 'eventTable'>" +
	"<caption>Upcoming Events</caption>" +
	"<tr><th>Date</th><th>Event</th><th>Price</th></tr>";
var endDate = new Date(thisDay.getTime() + 14 * 24 * 60 * 60 * 1000);

for(var i = 0; i < eventDates.length; i++){
	var eventDate = new Date(eventDates[i]);
	var eventDay = eventDate.toDateString();
	var eventTime = eventDate.toLocaleDateString();
	var description = eventDescriptions[i];
	var price = eventPrices[i];
	
	if(thisDay <= eventDate && eventDate <= endDate)
		{
			tableHTML = tableHTML.concat("<tr><td>").concat(eventDay).concat("@").concat(eventTime).concat("</td><td>").concat(description).concat("</td><td>").concat(price).concat("</td></tr>");
		}
}
tableHTML = tableHTML.concat('</table>');
document.getElementById("eventList").innerHTML = tableHTML;